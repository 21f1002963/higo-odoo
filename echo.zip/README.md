# higo-odoo

* [Mobile Demo](https://drive.google.com/file/d/1z0QRi7ZRKEv8qnZcmgsdmQGKXdc-5NL7/view?usp=sharing)
* [Pc Demo](https://drive.google.com/file/d/12tFlwPNw4iwfevLF8NiRQtGAHOT9ibEZ/view?usp=sharing)
